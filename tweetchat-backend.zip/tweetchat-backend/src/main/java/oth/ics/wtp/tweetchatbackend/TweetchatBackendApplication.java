package oth.ics.wtp.tweetchatbackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;



@SpringBootApplication
public class TweetchatBackendApplication {

    public static void main(String[] args) {
        SpringApplication.run(TweetchatBackendApplication.class, args);
    }

}
