package oth.ics.wtp.tweetchatbackend.Controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import oth.ics.wtp.tweetchatbackend.DTO.PostCreationDto;
import oth.ics.wtp.tweetchatbackend.DTO.UserLoginDto;
import oth.ics.wtp.tweetchatbackend.entity.User;
import oth.ics.wtp.tweetchatbackend.Repository.PostRepository;
import oth.ics.wtp.tweetchatbackend.Repository.UserRepository;
import oth.ics.wtp.tweetchatbackend.Service.PostService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.mock.web.MockMultipartFile;

import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf; // <-- IMPORT
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
@Transactional
class PostControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PostRepository postRepository;

    @Autowired
    private PostService postService;

    @Autowired
    private PasswordEncoder passwordEncoder;

    private User userA;
    private User userB;

    @BeforeEach
    void setUp() {
        postRepository.deleteAll();
        userRepository.deleteAll();

        userA = new User();
        userA.setUsername("userA");
        userA.setPassword(passwordEncoder.encode("passwordA"));
        userA = userRepository.save(userA);

        userB = new User();
        userB.setUsername("userB");
        userB.setPassword(passwordEncoder.encode("passwordB"));
        userB = userRepository.save(userB);
    }



    @Test
    void createPost_whenAuthenticated_shouldSucceed() throws Exception {

        String token = loginAndGetToken("userA", "passwordA");
        PostCreationDto postDto = new PostCreationDto();
        postDto.setText("A new post from userA");


        MockMultipartFile postPart = new MockMultipartFile(
                "postData",
                "",
                "application/json",
                objectMapper.writeValueAsString(postDto).getBytes()
        );


        mockMvc.perform(multipart("/api/posts")
                        .file(postPart) // Add the JSON data as a file part
                        .header("Authorization", "Bearer " + token)
                        .with(csrf()))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.text", is("A new post from userA")))
                .andExpect(jsonPath("$.authorUsername", is("userA")));
    }

    @Test
    void getTimelineFeed_whenFollowingUser_shouldReturnTheirPosts() throws Exception {
        userA.followUser(userB);
        userRepository.save(userA);
        postService.createPost(new PostCreationDto("Post by B"), "userB", null);
        String token = loginAndGetToken("userA", "passwordA");

        mockMvc.perform(get("/api/posts/feed")
                        .header("Authorization", "Bearer " + token))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(1)))
                .andExpect(jsonPath("$[0].text", is("Post by B")));
    }

    private String loginAndGetToken(String username, String password) throws Exception {
        UserLoginDto loginDto = new UserLoginDto();
        loginDto.setUsername(username);
        loginDto.setPassword(password);

        MvcResult result = mockMvc.perform(post("/api/auth/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(loginDto))
                        .with(csrf())) // Also good to add it here for consistency
                .andExpect(status().isOk())
                .andReturn();

        String responseString = result.getResponse().getContentAsString();
        return objectMapper.readTree(responseString).get("accessToken").asText();
    }
}