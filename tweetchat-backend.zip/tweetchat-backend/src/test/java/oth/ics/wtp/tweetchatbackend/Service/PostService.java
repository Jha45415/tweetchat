package oth.ics.wtp.tweetchatbackend.Service;

import oth.ics.wtp.tweetchatbackend.DTO.PostCreationDto;
import oth.ics.wtp.tweetchatbackend.entity.Post;
import oth.ics.wtp.tweetchatbackend.entity.User;
import oth.ics.wtp.tweetchatbackend.Repository.PostRepository;
import oth.ics.wtp.tweetchatbackend.Repository.UserRepository;
import oth.ics.wtp.tweetchatbackend.DTO.PostDto;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Pageable;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class PostServiceTest {

    @Mock
    private PostRepository postRepository;

    @Mock
    private UserRepository userRepository;

    @InjectMocks
    private PostService postService;

    // --- DECLARED FIELDS FOR ALL TESTS ---
    private User userA;
    private User userB;
    private Post postFromB;

    @BeforeEach
    void setUp() {

        userA = new User();
        userA.setId(1L);
        userA.setUsername("userA");

        userB = new User();
        userB.setId(2L);
        userB.setUsername("userB");

        postFromB = new Post();
        postFromB.setId(100L);
        postFromB.setText("Post from userB");
        postFromB.setAuthor(userB);
    }

    @Test
    void createPost_whenUserExists_shouldCreateAndSavePost() {

        PostCreationDto postDto = new PostCreationDto();
        postDto.setText("New test post");


        when(userRepository.findByUsername("userA")).thenReturn(Optional.of(userA));
        when(postRepository.save(any(Post.class))).thenAnswer(invocation -> invocation.getArgument(0));


        Post createdPost = postService.createPost(postDto, "userA", null);


        assertNotNull(createdPost);
        assertEquals("New test post", createdPost.getText());
        assertEquals("userA", createdPost.getAuthor().getUsername());
        verify(postRepository, times(1)).save(any(Post.class));
    }

    @Test
    void likePost_whenUserLikesAnotherUsersPost_shouldAddLike() {
        when(postRepository.findById(100L)).thenReturn(Optional.of(postFromB));
        when(userRepository.findByUsername("userA")).thenReturn(Optional.of(userA));

        postService.likePost(100L, "userA");

        assertTrue(postFromB.getLikedByUsers().contains(userA));
    }

    @Test
    void likePost_whenUserLikesOwnPost_shouldThrowException() {
        when(postRepository.findById(100L)).thenReturn(Optional.of(postFromB));
        when(userRepository.findByUsername("userB")).thenReturn(Optional.of(userB));

        assertThrows(IllegalArgumentException.class, () -> {
            postService.likePost(100L, "userB");
        });
    }

    @Test
    void getAggregatedTimeline_whenUserFollowsOthers_shouldReturnTheirPosts() {

        userA.getFollowing().add(userB); // userA follows userB
        when(userRepository.findByUsername("userA")).thenReturn(Optional.of(userA));

        when(postRepository.findByAuthorInOrderByTimestampDesc(anyList(), any(Pageable.class)))
                .thenReturn(Collections.singletonList(postFromB));


        List<PostDto> timeline = postService.getAggregatedTimeline("userA");


        assertFalse(timeline.isEmpty());
        assertEquals(1, timeline.size());
        assertEquals("userB", timeline.get(0).getAuthorUsername());
    }
    @Test
    void unlikePost_whenUserHasLikedPost_shouldRemoveLike() {

        postFromB.getLikedByUsers().add(userA);
        assertTrue(postFromB.getLikedByUsers().contains(userA)); // Verify setup

        when(postRepository.findById(100L)).thenReturn(Optional.of(postFromB));
        when(userRepository.findByUsername("userA")).thenReturn(Optional.of(userA));


        postService.unlikePost(100L, "userA");


        assertFalse(postFromB.getLikedByUsers().contains(userA), "Like should be removed");
    }
    @Test
    void unlikePost_whenUserHasNotLikedPost_shouldThrowException() {

        assertFalse(postFromB.getLikedByUsers().contains(userA));

        when(postRepository.findById(100L)).thenReturn(Optional.of(postFromB));
        when(userRepository.findByUsername("userA")).thenReturn(Optional.of(userA));


        assertThrows(IllegalArgumentException.class, () -> {
            postService.unlikePost(100L, "userA");
        });
    }
    @Test
    void getAggregatedTimeline_whenUserFollowsNoOne_shouldReturnEmptyList() {

        when(userRepository.findByUsername("userA")).thenReturn(Optional.of(userA));


        List<PostDto> timeline = postService.getAggregatedTimeline("userA");


        assertTrue(timeline.isEmpty());

        verify(postRepository, never()).findByAuthorInOrderByTimestampDesc(anyList(), any(Pageable.class));
    }

}