
package oth.ics.wtp.tweetchatbackend.Service;

import oth.ics.wtp.tweetchatbackend.entity.User;
import oth.ics.wtp.tweetchatbackend.Repository.UserRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import oth.ics.wtp.tweetchatbackend.DTO.UserDto;
import oth.ics.wtp.tweetchatbackend.DTO.UserRegistrationDto;
import java.util.List;
import java.util.Collections;

@ExtendWith(MockitoExtension.class)
class UserServiceTest {

    @Mock
    private UserRepository userRepository;

    @Mock
    private PasswordEncoder passwordEncoder;

    @InjectMocks
    private UserService userService;

    private User userA;
    private User userB;

    @BeforeEach
    void setUp() {
        userA = new User();
        userA.setId(1L);
        userA.setUsername("userA");
        userA.setPassword("hashedPasswordA");

        userB = new User();
        userB.setId(2L);
        userB.setUsername("userB");
        userB.setPassword("hashedPasswordB");
    }

    @Test
    void followUser_shouldAddUserToFollowingSet() {

        when(userRepository.findByUsername("userA")).thenReturn(Optional.of(userA));
        when(userRepository.findByUsername("userB")).thenReturn(Optional.of(userB));


        userService.followUser("userA", "userB");


        assertTrue(userA.getFollowing().contains(userB), "userA should be following userB");
        assertTrue(userB.getFollowers().contains(userA), "userB should have userA as a follower");
    }

    @Test
    void unfollowUser_shouldRemoveUserFromFollowingSet() {

        userA.getFollowing().add(userB);
        userB.getFollowers().add(userA);
        when(userRepository.findByUsername("userA")).thenReturn(Optional.of(userA));
        when(userRepository.findByUsername("userB")).thenReturn(Optional.of(userB));


        userService.unfollowUser("userA", "userB");


        assertFalse(userA.getFollowing().contains(userB), "userA should no longer be following userB");
        assertFalse(userB.getFollowers().contains(userA), "userB should no longer have userA as a follower");
    }

    @Test
    void followUser_whenUserNotFound_shouldThrowException() {

        when(userRepository.findByUsername("userA")).thenReturn(Optional.empty());


        assertThrows(IllegalArgumentException.class, () -> {
            userService.followUser("userA", "userB");
        }, "Should throw an exception if the current user is not found");
    }
    @Test
    void registerNewUser_whenUsernameIsNew_shouldSaveAndReturnUser() {

        UserRegistrationDto dto = new UserRegistrationDto();
        dto.setUsername("brandNewUser");
        dto.setPassword("a-strong-password");


        when(userRepository.existsByUsername("brandNewUser")).thenReturn(false);
        when(passwordEncoder.encode("a-strong-password")).thenReturn("hashed-password-string");

        when(userRepository.save(any(User.class))).thenAnswer(invocation -> invocation.getArgument(0));


        User savedUser = userService.registerNewUser(dto);


        assertNotNull(savedUser);
        assertEquals("brandNewUser", savedUser.getUsername());
        assertEquals("hashed-password-string", savedUser.getPassword());
        verify(userRepository, times(1)).save(any(User.class));
    }
    @Test
    void registerNewUser_whenUsernameExists_shouldThrowException() {
        // Arrange
        UserRegistrationDto dto = new UserRegistrationDto();
        dto.setUsername("existingUser");
        dto.setPassword("a-password");
        when(userRepository.existsByUsername("existingUser")).thenReturn(true);


        assertThrows(IllegalArgumentException.class, () -> {
            userService.registerNewUser(dto);
        });

        verify(userRepository, never()).save(any(User.class));
    }
    @Test
    void searchUsers_shouldReturnCorrectDtoList() {

        userA.getFollowing().add(userB);

        when(userRepository.findByUsername("userA")).thenReturn(Optional.of(userA));
        when(userRepository.findByUsernameContainingIgnoreCase("userB"))
                .thenReturn(Collections.singletonList(userB));


        List<UserDto> results = userService.searchUsers("userB", "userA");


        assertEquals(1, results.size());
        assertEquals("userB", results.get(0).getUsername());
        assertTrue(results.get(0).isFollowedByCurrentUser(), "Search result should show that userB is followed by userA");
    }
    @Test
    void getUserProfile_shouldReturnCorrectDto() {

        userA.getFollowing().add(userB);
        when(userRepository.findByUsername("userB")).thenReturn(Optional.of(userB));
        when(userRepository.findByUsername("userA")).thenReturn(Optional.of(userA));


        UserDto profileDto = userService.getUserProfile("userB", "userA");


        assertNotNull(profileDto);
        assertEquals("userB", profileDto.getUsername());
        assertTrue(profileDto.isFollowedByCurrentUser());
    }
    @Test
    void getUserProfile_whenUserIsNotFound_shouldThrowException() {

        String profileUsername = "nonexistentUser";
        String currentUsername = "currentUser";


        when(userRepository.findByUsername(profileUsername)).thenReturn(Optional.empty());


        assertThrows(IllegalArgumentException.class, () -> {
            userService.getUserProfile(profileUsername, currentUsername);
        });
    }
    @Test
    void searchUsers_whenResultIncludesSelf_shouldFilterOutCurrentUser() {

        when(userRepository.findByUsername("userA")).thenReturn(Optional.of(userA));

        when(userRepository.findByUsernameContainingIgnoreCase("user"))
                .thenReturn(List.of(userA, userB));


        List<UserDto> results = userService.searchUsers("user", "userA");


        assertEquals(1, results.size(), "Search results should not include the current user");
        assertEquals("userB", results.get(0).getUsername());
    }
    @Test
    void searchUsers_whenSearchTermIsEmpty_shouldReturnEmptyListAndNotCallRepoSearch() {

        String currentUsername = "userA";


        List<UserDto> resultsForNull = userService.searchUsers(null, currentUsername);
        List<UserDto> resultsForBlank = userService.searchUsers("   ", currentUsername);


        assertTrue(resultsForNull.isEmpty(), "Should return empty list for null search term");
        assertTrue(resultsForBlank.isEmpty(), "Should return empty list for blank search term");


        verify(userRepository, never()).findByUsernameContainingIgnoreCase(anyString());
    }


}