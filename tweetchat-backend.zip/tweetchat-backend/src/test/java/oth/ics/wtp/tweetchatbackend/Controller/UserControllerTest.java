package oth.ics.wtp.tweetchatbackend.Controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import oth.ics.wtp.tweetchatbackend.config.SecurityConfig;
import oth.ics.wtp.tweetchatbackend.DTO.UserDto;
import oth.ics.wtp.tweetchatbackend.Security.JwtTokenProvider;
import oth.ics.wtp.tweetchatbackend.Service.UserDetailsServiceImpl;
import oth.ics.wtp.tweetchatbackend.Service.UserService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;
import oth.ics.wtp.tweetchatbackend.controller.UserController;

import java.util.Collections;
import java.util.List;

import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.doNothing;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(controllers = UserController.class)
@Import(SecurityConfig.class)
class UserControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private UserService userService;


    @MockBean
    private JwtTokenProvider jwtTokenProvider;
    @MockBean
    private UserDetailsServiceImpl userDetailsService;

    @Test
    @WithMockUser(username = "currentUser")
    void followUser_whenValid_shouldReturnOk() throws Exception {

        String userToFollow = "userB";
        doNothing().when(userService).followUser("currentUser", userToFollow);


        mockMvc.perform(post("/api/users/{username}/follow", userToFollow))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$").value("Successfully followed " + userToFollow));
    }

    @Test
    @WithMockUser(username = "currentUser")
    void followUser_whenFollowingSelf_shouldReturnBadRequest() throws Exception {

        String userToFollow = "currentUser";



        mockMvc.perform(post("/api/users/{username}/follow", userToFollow))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$").value("You cannot follow yourself."));
    }

    @Test
    @WithMockUser(username = "currentUser")
    void searchUsers_shouldReturnUserList() throws Exception {

        UserDto foundUser = new UserDto();
        foundUser.setId(2L);
        foundUser.setUsername("foundUser");
        foundUser.setFollowedByCurrentUser(false);

        List<UserDto> userList = Collections.singletonList(foundUser);
        given(userService.searchUsers("found", "currentUser")).willReturn(userList);


        mockMvc.perform(get("/api/users/search").param("q", "found"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(1)))
                .andExpect(jsonPath("$[0].username", is("foundUser")));
    }
    @Test
    @WithMockUser(username = "currentUser")
    void getUserProfile_whenUserExists_shouldReturnUserProfile() throws Exception {

        String profileUsername = "profileUser";
        UserDto userDto = new UserDto();
        userDto.setUsername(profileUsername);
        userDto.setFollowedByCurrentUser(true);

        given(userService.getUserProfile(profileUsername, "currentUser")).willReturn(userDto);


        mockMvc.perform(get("/api/users/{username}", profileUsername))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.username", is(profileUsername)))
                .andExpect(jsonPath("$.followedByCurrentUser", is(true)));
    }
}