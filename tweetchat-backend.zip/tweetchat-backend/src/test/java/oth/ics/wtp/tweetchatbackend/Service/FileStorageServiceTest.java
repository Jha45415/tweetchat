package oth.ics.wtp.tweetchatbackend.Service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.*;


class FileStorageServiceTest {

    @TempDir
    Path tempDir;

    private FileStorageService fileStorageService;

    @BeforeEach
    void setUp() {
        fileStorageService = new FileStorageService();

        ReflectionTestUtils.setField(fileStorageService, "fileStorageLocation", tempDir);
    }

    @Test
    void storeFile_shouldSaveFileToTempDirectory() throws IOException {
        MockMultipartFile multipartFile = new MockMultipartFile(
                "file",
                "test-image.jpg",
                "image/jpeg",
                "test image content".getBytes()
        );

        String fileName = fileStorageService.storeFile(multipartFile);

        assertNotNull(fileName);
        assertTrue(Files.exists(tempDir.resolve(fileName)));
        assertEquals("test image content", new String(Files.readAllBytes(tempDir.resolve(fileName))));
    }

    @Test
    void storeFile_withInvalidPath_shouldThrowException() {
        MockMultipartFile multipartFile = new MockMultipartFile(
                "file",
                "../invalid-path.txt",
                "text/plain",
                "some content".getBytes()
        );

        Exception exception = assertThrows(RuntimeException.class, () -> {
            fileStorageService.storeFile(multipartFile);
        });

        assertTrue(exception.getMessage().contains("invalid path sequence"));
    }

    @Test
    void storeFile_withEmptyFile_shouldStoreEmptyFile() throws IOException {
        MockMultipartFile multipartFile = new MockMultipartFile(
                "file",
                "empty.txt",
                "text/plain",
                new byte[0]
        );

        String fileName = fileStorageService.storeFile(multipartFile);

        assertNotNull(fileName);
        assertTrue(Files.exists(tempDir.resolve(fileName)));
        assertEquals(0, Files.size(tempDir.resolve(fileName)));
    }
}