package oth.ics.wtp.tweetchatbackend.entity;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class UserTest {

    private User user1;
    private User user2;

    @BeforeEach
    void setUp() {
        user1 = new User();
        user1.setId(1L);
        user1.setUsername("user1");

        user2 = new User();
        user2.setId(2L);
        user2.setUsername("user2");
    }

    @Test
    void followUser_shouldUpdateFollowingAndFollowersSets() {

        user1.followUser(user2);

        assertTrue(user1.getFollowing().contains(user2));
        assertTrue(user2.getFollowers().contains(user1));
    }

    @Test
    void unfollowUser_shouldUpdateFollowingAndFollowersSets() {

        user1.followUser(user2); // First, follow


        user1.unfollowUser(user2); // Then, unfollow


        assertFalse(user1.getFollowing().contains(user2));
        assertFalse(user2.getFollowers().contains(user1));
    }

    @Test
    void testEqualsAndHashCode() {
        User sameAsUser1 = new User();
        sameAsUser1.setId(1L);
        sameAsUser1.setUsername("user1");

        assertEquals(user1, sameAsUser1);
        assertEquals(user1.hashCode(), sameAsUser1.hashCode());
        assertNotEquals(user1, user2);
    }
}